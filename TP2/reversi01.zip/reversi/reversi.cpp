#include "reversi.h"
#include "ui_reversi.h"
#include <QDebug>

Reversi::Reversi(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Reversi)
{
    ui->setupUi(this);

    for(int r = 0; r < 8; r++){
        for(int c = 0; c < 8; c++){
            Cell* cell = this->findChild<Cell*>(QString("cell%1%2").arg(r).arg(c));
            Q_ASSERT(cell != 0);
            cell->setRow(r);
            cell->setCol(c);
            QObject::connect(cell, SIGNAL(clicked(bool)), this, SLOT(play());
            m_cells[r][c] = cell;
        }
    }
    m_cells[3][3]->setPlayer(1);
    m_cells[3][4]->setPlayer(2);
    m_cells[4][3]->setPlayer(2);
    m_cells[4][4]->setPlayer(1);

    QObject::connect(ui->actionSair,SIGNAL(toggled(bool)), qApp , SLOT(quit()));

    this->adjustSize();
    this->setFixedSize(this->size());
}

Reversi::~Reversi()
{
    delete ui;
}

void Reversi::play()
{
    Cell* cell = qobject_cast<Cell*>(QObject::sender())
    qDebug() << "Jogando..";
}
