#ifndef CELL_H
#define CELL_H

#include <QPushButton>

class Cell : public QPushButton{
    Q_OBJECT
    Q_PROPERTY(int player READ player WRITE setPlayer NOTIFY playerChanged)

public:
    explicit Cell(QWidget *parent = 0);
    virtual ~Cell();
    int player() const;
    int row() const{
        return m_row;
    }
    int col(){
        return m_col;
    }

    void setRow() const{
        m_row = row;
    }
    void setCol(){
        m_col = col;
    }

signals:
     void playerChanged(int oldplayer, int newplayer);

public slots:
    void setPlayer(int player);

private:
    int m_player;
    int m_row;
    int m_col;

};

#endif // CELL_H
