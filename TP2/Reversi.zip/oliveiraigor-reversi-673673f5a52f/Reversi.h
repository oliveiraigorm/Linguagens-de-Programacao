#ifndef REVERSI_H
#define REVERSI_H

#include <QMainWindow>

class Cell;

namespace Ui {
    class Reversi;
}

class Reversi : public QMainWindow {
    Q_OBJECT

public:
    explicit Reversi(QWidget *parent = 0);
    virtual ~Reversi();

private:
    Ui::Reversi *ui;
    Cell* m_cells[8][8];
    int m_count[2];
    int player = 1;
    int DX[8] = { -1,  0,  1, -1, 1, -1, 0, 1 };
    int DY[8] = { -1, -1, -1,  0, 0,  1, 1, 1 };

private slots:
    void play();
    void reset();
    void showAbout();
    void updateStatus(int newplayer,int oldplayer);
    bool isValid(int row, int col);
    bool gameOver();
    void flip(int row, int col);
};

#endif // REVERSI_H
