#include "Reversi.h"
#include "ui_reversi.h"
#include <QMessageBox>
#include <QDebug>

Reversi::Reversi(QWidget *parent) :
    QMainWindow(parent),

    ui(new Ui::Reversi) {

    ui->setupUi(this);
    m_count[0] = 0;
    m_count[1] = 0;
    for (int r = 0; r < 8; r++) {
        for (int c = 0; c < 8; c++) {
            Cell* cell = this->findChild<Cell*>(
                 QString("cell%1%2").arg(r).arg(c));
            Q_ASSERT(cell != 0);
            cell->setRow(r);
            cell->setCol(c);
            QObject::connect(
                cell,
                SIGNAL(playerChanged(int,int)),
                this,
                SLOT(updateStatus(int,int))
            );
            QObject::connect(
                cell,
                SIGNAL(clicked(bool)),
                this,
                SLOT(play())
            );


            m_cells[r][c] = cell;
        }
    }

    m_cells[3][3]->setPlayer(1);
    m_cells[3][4]->setPlayer(2);
    m_cells[4][3]->setPlayer(2);
    m_cells[4][4]->setPlayer(1);


    this->reset();
    QObject::connect(
        ui->actionNovo,
        SIGNAL(triggered(bool)),
        this,
        SLOT(reset())
    );
    QObject::connect(
        ui->actionSair,
        SIGNAL(triggered(bool)),
        qApp,
        SLOT(quit())
    );
    QObject::connect(
        ui->actionSobre,
        SIGNAL(triggered(bool)),
        this,
        SLOT(showAbout())
    );

    //this->updateStatus();
    this->adjustSize();
    this->setFixedSize(this->size());
}

Reversi::~Reversi() {
    delete ui;
}

void Reversi::play() {
    Cell* cell = qobject_cast<Cell*>(QObject::sender());
    Q_ASSERT(cell != 0);
    if(isValid(cell->row(), cell->col()) ){
        cell->setPlayer(player);
        flip(cell->row(), cell->col());

        if(player == 1)
            player = 2;
        else if(player == 2)
            player = 1;
        qDebug() << "Play on ("
                 << cell->row() << ", "
                 << cell->col() << ")";
    }
    else{
        qDebug() << "Posição inválida";
    }
}
bool Reversi::gameOver(){
    int over = false;
    for(int i = 0; i < 8; i++){
        for(int j = 0; j < 8; j++){
            if(isValid(i, j)){
                return false;
            }
        }
    }
    return true;
}
bool Reversi::isValid(int row, int col){
    if(m_cells[row][col]->player() != 0){
        return false;
    }
    for(int i = 0; i < 8; i++){
        bool saw = false;
        int x, y;
        x = row;
        y = col;
        for(int j = 0; j < 8; j++){
            x += DX[i];
            y += DY[i];
            if(!((x >= 0) && (x < 8) && (y >= 0) && (y < 8))){
                break;
            }

            if(m_cells[x][y]->player()== NULL){
                break;
            }

            else if (m_cells[x][y]->player() != player &&
                     m_cells[x][y]->player() != 0) {
                saw = true;
            }
            else if (saw) {
                return true;
            }
            else{
                break;
            }
        }
    }
    return false;
}
void Reversi::flip(int row, int col){
    int flip[8][8];
    for(int i = 0; i < 8; i++){
        for(int j = 0; j < 8; j++){
            flip[i][j] = 0;
        }
    }
    for(int i = 0; i < 8; i++){
        bool saw = false;
        int x, y;
        x = row;
        y = col;
        for(int j = 0; j < 8; j++){
            x += DX[i];
            y += DY[i];
            if(!((x >= 0) && (x < 8) && (y >= 0) && (y < 8))){
                break;
            }

            if(m_cells[x][y]->player() == NULL){
                break;
            }

            else if (m_cells[x][y]->player() != player &&
                     m_cells[x][y]->player() != 0 &&
                     m_cells[x + DX[i]][y + DY[i]]->player() != 0 &&
                     m_cells[x + DX[i]][y + DY[i]]->player() != NULL) {
                flip[x][y] = 1;
            }
            else{
                for(int ii = 0; ii < 8; ii++){
                    for(int jj = 0; jj < 8; jj++){
                        if(flip[ii][jj] == 1){
                            qDebug() << "vira"
                                     << ii
                                     << jj;
                            m_cells[ii][jj]->setPlayer(player);
                        }
                    }
                }
            }
        }
    }

}
void Reversi::reset() {
    for(int i = 0; i < 8; i++){
        for(int j = 0; j < 8;j++){
            m_cells[i][j]->setPlayer(0);
        }
    }
    m_cells[3][3]->setPlayer(1);
    m_cells[3][4]->setPlayer(2);
    m_cells[4][3]->setPlayer(2);
    m_cells[4][4]->setPlayer(1);
    player = 1;
}
void Reversi::showAbout() {
    QMessageBox::information(this, tr("Sobre"), tr("Igor Miranda"));
}

void Reversi::updateStatus(int oldplayer, int newplayer) {
    if(oldplayer > 0)
        m_count[oldplayer-1]--;
    if(newplayer > 0)
        m_count[newplayer-1]++;
    ui->statusBar->showMessage(QString("Vermelho: %1 vs Azul: %2").arg(m_count[0]).arg(m_count[1]));
}
