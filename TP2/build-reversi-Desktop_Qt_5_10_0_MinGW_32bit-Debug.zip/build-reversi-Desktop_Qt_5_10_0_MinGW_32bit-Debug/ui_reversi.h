/********************************************************************************
** Form generated from reading UI file 'reversi.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REVERSI_H
#define UI_REVERSI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Reversi
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QPushButton *cell00;
    QPushButton *cell01;
    QPushButton *cell02;
    QPushButton *cell03;
    QPushButton *cell04;
    QPushButton *cell05;
    QPushButton *cell06;
    QPushButton *cell07;
    QPushButton *cell10;
    QPushButton *cell11;
    QPushButton *cell12;
    QPushButton *cell13;
    QPushButton *cell14;
    QPushButton *cell15;
    QPushButton *cell16;
    QPushButton *cell17;
    QPushButton *cell20;
    QPushButton *pushButton_26;
    QPushButton *pushButton_21;
    QPushButton *pushButton_20;
    QPushButton *pushButton_19;
    QPushButton *pushButton_22;
    QPushButton *pushButton_32;
    QPushButton *pushButton_25;
    QPushButton *pushButton_27;
    QPushButton *pushButton_28;
    QPushButton *pushButton_23;
    QPushButton *pushButton_17;
    QPushButton *pushButton_30;
    QPushButton *cell_2;
    QPushButton *pushButton_24;
    QPushButton *pushButton_29;
    QPushButton *pushButton_48;
    QPushButton *pushButton_42;
    QPushButton *pushButton_37;
    QPushButton *pushButton_36;
    QPushButton *pushButton_35;
    QPushButton *pushButton_38;
    QPushButton *cell;
    QPushButton *pushButton_41;
    QPushButton *pushButton_43;
    QPushButton *pushButton_45;
    QPushButton *pushButton_39;
    QPushButton *pushButton_33;
    QPushButton *pushButton_47;
    QPushButton *pushButton_34;
    QPushButton *pushButton_40;
    QPushButton *pushButton_46;
    QPushButton *pushButton_71;
    QPushButton *pushButton_61;
    QPushButton *pushButton_56;
    QPushButton *pushButton_55;
    QPushButton *pushButton_54;
    QPushButton *pushButton_57;
    QPushButton *pushButton_72;
    QPushButton *pushButton_60;
    QPushButton *pushButton_44;
    QPushButton *pushButton_52;
    QPushButton *pushButton_53;
    QPushButton *pushButton_65;
    QPushButton *pushButton_66;
    QPushButton *pushButton_67;
    QPushButton *pushButton_68;
    QPushButton *pushButton_69;
    QMenuBar *menuBar;
    QMenu *menuJogo;
    QMenu *menuAjuda;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Reversi)
    {
        if (Reversi->objectName().isEmpty())
            Reversi->setObjectName(QStringLiteral("Reversi"));
        Reversi->resize(300, 341);
        centralWidget = new QWidget(Reversi);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(0);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(10, 10, 10, 10);
        cell00 = new QPushButton(centralWidget);
        cell00->setObjectName(QStringLiteral("cell00"));
        cell00->setMinimumSize(QSize(35, 35));
        cell00->setMaximumSize(QSize(35, 35));
        cell00->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 1px;"));
        cell00->setFlat(true);

        gridLayout->addWidget(cell00, 0, 0, 1, 1);

        cell01 = new QPushButton(centralWidget);
        cell01->setObjectName(QStringLiteral("cell01"));
        cell01->setMinimumSize(QSize(35, 35));
        cell01->setMaximumSize(QSize(35, 35));
        cell01->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell01->setFlat(true);

        gridLayout->addWidget(cell01, 0, 1, 1, 1);

        cell02 = new QPushButton(centralWidget);
        cell02->setObjectName(QStringLiteral("cell02"));
        cell02->setMinimumSize(QSize(35, 35));
        cell02->setMaximumSize(QSize(35, 35));
        cell02->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell02->setFlat(true);

        gridLayout->addWidget(cell02, 0, 2, 1, 1);

        cell03 = new QPushButton(centralWidget);
        cell03->setObjectName(QStringLiteral("cell03"));
        cell03->setMinimumSize(QSize(35, 35));
        cell03->setMaximumSize(QSize(35, 35));
        cell03->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell03->setFlat(true);

        gridLayout->addWidget(cell03, 0, 3, 1, 1);

        cell04 = new QPushButton(centralWidget);
        cell04->setObjectName(QStringLiteral("cell04"));
        cell04->setMinimumSize(QSize(35, 35));
        cell04->setMaximumSize(QSize(35, 35));
        cell04->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell04->setFlat(true);

        gridLayout->addWidget(cell04, 0, 4, 1, 1);

        cell05 = new QPushButton(centralWidget);
        cell05->setObjectName(QStringLiteral("cell05"));
        cell05->setMinimumSize(QSize(35, 35));
        cell05->setMaximumSize(QSize(35, 35));
        cell05->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell05->setFlat(true);

        gridLayout->addWidget(cell05, 0, 5, 1, 1);

        cell06 = new QPushButton(centralWidget);
        cell06->setObjectName(QStringLiteral("cell06"));
        cell06->setMinimumSize(QSize(35, 35));
        cell06->setMaximumSize(QSize(35, 35));
        cell06->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell06->setFlat(true);

        gridLayout->addWidget(cell06, 0, 6, 1, 1);

        cell07 = new QPushButton(centralWidget);
        cell07->setObjectName(QStringLiteral("cell07"));
        cell07->setMinimumSize(QSize(35, 35));
        cell07->setMaximumSize(QSize(35, 35));
        cell07->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell07->setFlat(true);

        gridLayout->addWidget(cell07, 0, 7, 1, 1);

        cell10 = new QPushButton(centralWidget);
        cell10->setObjectName(QStringLiteral("cell10"));
        cell10->setMinimumSize(QSize(35, 35));
        cell10->setMaximumSize(QSize(35, 35));
        cell10->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 1px;"));
        cell10->setFlat(true);

        gridLayout->addWidget(cell10, 1, 0, 1, 1);

        cell11 = new QPushButton(centralWidget);
        cell11->setObjectName(QStringLiteral("cell11"));
        cell11->setMinimumSize(QSize(35, 35));
        cell11->setMaximumSize(QSize(35, 35));
        cell11->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell11->setFlat(true);

        gridLayout->addWidget(cell11, 1, 1, 1, 1);

        cell12 = new QPushButton(centralWidget);
        cell12->setObjectName(QStringLiteral("cell12"));
        cell12->setMinimumSize(QSize(35, 35));
        cell12->setMaximumSize(QSize(35, 35));
        cell12->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell12->setFlat(true);

        gridLayout->addWidget(cell12, 1, 2, 1, 1);

        cell13 = new QPushButton(centralWidget);
        cell13->setObjectName(QStringLiteral("cell13"));
        cell13->setMinimumSize(QSize(35, 35));
        cell13->setMaximumSize(QSize(35, 35));
        cell13->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell13->setFlat(true);

        gridLayout->addWidget(cell13, 1, 3, 1, 1);

        cell14 = new QPushButton(centralWidget);
        cell14->setObjectName(QStringLiteral("cell14"));
        cell14->setMinimumSize(QSize(35, 35));
        cell14->setMaximumSize(QSize(35, 35));
        cell14->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell14->setFlat(true);

        gridLayout->addWidget(cell14, 1, 4, 1, 1);

        cell15 = new QPushButton(centralWidget);
        cell15->setObjectName(QStringLiteral("cell15"));
        cell15->setMinimumSize(QSize(35, 35));
        cell15->setMaximumSize(QSize(35, 35));
        cell15->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell15->setFlat(true);

        gridLayout->addWidget(cell15, 1, 5, 1, 1);

        cell16 = new QPushButton(centralWidget);
        cell16->setObjectName(QStringLiteral("cell16"));
        cell16->setMinimumSize(QSize(35, 35));
        cell16->setMaximumSize(QSize(35, 35));
        cell16->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell16->setFlat(true);

        gridLayout->addWidget(cell16, 1, 6, 1, 1);

        cell17 = new QPushButton(centralWidget);
        cell17->setObjectName(QStringLiteral("cell17"));
        cell17->setMinimumSize(QSize(35, 35));
        cell17->setMaximumSize(QSize(35, 35));
        cell17->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell17->setFlat(true);

        gridLayout->addWidget(cell17, 1, 7, 1, 1);

        cell20 = new QPushButton(centralWidget);
        cell20->setObjectName(QStringLiteral("cell20"));
        cell20->setMinimumSize(QSize(35, 35));
        cell20->setMaximumSize(QSize(35, 35));
        cell20->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 1px;"));
        cell20->setFlat(true);

        gridLayout->addWidget(cell20, 2, 0, 1, 1);

        pushButton_26 = new QPushButton(centralWidget);
        pushButton_26->setObjectName(QStringLiteral("pushButton_26"));
        pushButton_26->setMinimumSize(QSize(35, 35));
        pushButton_26->setMaximumSize(QSize(35, 35));
        pushButton_26->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_26->setFlat(true);

        gridLayout->addWidget(pushButton_26, 2, 1, 1, 1);

        pushButton_21 = new QPushButton(centralWidget);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setMinimumSize(QSize(35, 35));
        pushButton_21->setMaximumSize(QSize(35, 35));
        pushButton_21->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_21->setFlat(true);

        gridLayout->addWidget(pushButton_21, 2, 2, 1, 1);

        pushButton_20 = new QPushButton(centralWidget);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setMinimumSize(QSize(35, 35));
        pushButton_20->setMaximumSize(QSize(35, 35));
        pushButton_20->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_20->setFlat(true);

        gridLayout->addWidget(pushButton_20, 2, 3, 1, 1);

        pushButton_19 = new QPushButton(centralWidget);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setMinimumSize(QSize(35, 35));
        pushButton_19->setMaximumSize(QSize(35, 35));
        pushButton_19->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_19->setFlat(true);

        gridLayout->addWidget(pushButton_19, 2, 4, 1, 1);

        pushButton_22 = new QPushButton(centralWidget);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));
        pushButton_22->setMinimumSize(QSize(35, 35));
        pushButton_22->setMaximumSize(QSize(35, 35));
        pushButton_22->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_22->setFlat(true);

        gridLayout->addWidget(pushButton_22, 2, 5, 1, 1);

        pushButton_32 = new QPushButton(centralWidget);
        pushButton_32->setObjectName(QStringLiteral("pushButton_32"));
        pushButton_32->setMinimumSize(QSize(35, 35));
        pushButton_32->setMaximumSize(QSize(35, 35));
        pushButton_32->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_32->setFlat(true);

        gridLayout->addWidget(pushButton_32, 2, 6, 1, 1);

        pushButton_25 = new QPushButton(centralWidget);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));
        pushButton_25->setMinimumSize(QSize(35, 35));
        pushButton_25->setMaximumSize(QSize(35, 35));
        pushButton_25->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_25->setFlat(true);

        gridLayout->addWidget(pushButton_25, 2, 7, 1, 1);

        pushButton_27 = new QPushButton(centralWidget);
        pushButton_27->setObjectName(QStringLiteral("pushButton_27"));
        pushButton_27->setMinimumSize(QSize(35, 35));
        pushButton_27->setMaximumSize(QSize(35, 35));
        pushButton_27->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 1px;"));
        pushButton_27->setFlat(true);

        gridLayout->addWidget(pushButton_27, 3, 0, 1, 1);

        pushButton_28 = new QPushButton(centralWidget);
        pushButton_28->setObjectName(QStringLiteral("pushButton_28"));
        pushButton_28->setMinimumSize(QSize(35, 35));
        pushButton_28->setMaximumSize(QSize(35, 35));
        pushButton_28->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_28->setFlat(true);

        gridLayout->addWidget(pushButton_28, 3, 1, 1, 1);

        pushButton_23 = new QPushButton(centralWidget);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));
        pushButton_23->setMinimumSize(QSize(35, 35));
        pushButton_23->setMaximumSize(QSize(35, 35));
        pushButton_23->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_23->setFlat(true);

        gridLayout->addWidget(pushButton_23, 3, 2, 1, 1);

        pushButton_17 = new QPushButton(centralWidget);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setMinimumSize(QSize(35, 35));
        pushButton_17->setMaximumSize(QSize(35, 35));
        pushButton_17->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/red"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_17->setIcon(icon);
        pushButton_17->setIconSize(QSize(25, 25));
        pushButton_17->setFlat(true);

        gridLayout->addWidget(pushButton_17, 3, 3, 1, 1);

        pushButton_30 = new QPushButton(centralWidget);
        pushButton_30->setObjectName(QStringLiteral("pushButton_30"));
        pushButton_30->setMinimumSize(QSize(35, 35));
        pushButton_30->setMaximumSize(QSize(35, 35));
        pushButton_30->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/blue"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_30->setIcon(icon1);
        pushButton_30->setIconSize(QSize(25, 25));
        pushButton_30->setFlat(true);

        gridLayout->addWidget(pushButton_30, 3, 4, 1, 1);

        cell_2 = new QPushButton(centralWidget);
        cell_2->setObjectName(QStringLiteral("cell_2"));
        cell_2->setMinimumSize(QSize(35, 35));
        cell_2->setMaximumSize(QSize(35, 35));
        cell_2->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell_2->setFlat(true);

        gridLayout->addWidget(cell_2, 3, 5, 1, 1);

        pushButton_24 = new QPushButton(centralWidget);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));
        pushButton_24->setMinimumSize(QSize(35, 35));
        pushButton_24->setMaximumSize(QSize(35, 35));
        pushButton_24->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_24->setFlat(true);

        gridLayout->addWidget(pushButton_24, 3, 6, 1, 1);

        pushButton_29 = new QPushButton(centralWidget);
        pushButton_29->setObjectName(QStringLiteral("pushButton_29"));
        pushButton_29->setMinimumSize(QSize(35, 35));
        pushButton_29->setMaximumSize(QSize(35, 35));
        pushButton_29->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_29->setFlat(true);

        gridLayout->addWidget(pushButton_29, 3, 7, 1, 1);

        pushButton_48 = new QPushButton(centralWidget);
        pushButton_48->setObjectName(QStringLiteral("pushButton_48"));
        pushButton_48->setMinimumSize(QSize(35, 35));
        pushButton_48->setMaximumSize(QSize(35, 35));
        pushButton_48->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 1px;"));
        pushButton_48->setFlat(true);

        gridLayout->addWidget(pushButton_48, 4, 0, 1, 1);

        pushButton_42 = new QPushButton(centralWidget);
        pushButton_42->setObjectName(QStringLiteral("pushButton_42"));
        pushButton_42->setMinimumSize(QSize(35, 35));
        pushButton_42->setMaximumSize(QSize(35, 35));
        pushButton_42->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_42->setFlat(true);

        gridLayout->addWidget(pushButton_42, 4, 1, 1, 1);

        pushButton_37 = new QPushButton(centralWidget);
        pushButton_37->setObjectName(QStringLiteral("pushButton_37"));
        pushButton_37->setMinimumSize(QSize(35, 35));
        pushButton_37->setMaximumSize(QSize(35, 35));
        pushButton_37->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_37->setFlat(true);

        gridLayout->addWidget(pushButton_37, 4, 2, 1, 1);

        pushButton_36 = new QPushButton(centralWidget);
        pushButton_36->setObjectName(QStringLiteral("pushButton_36"));
        pushButton_36->setMinimumSize(QSize(35, 35));
        pushButton_36->setMaximumSize(QSize(35, 35));
        pushButton_36->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_36->setIcon(icon1);
        pushButton_36->setIconSize(QSize(25, 25));
        pushButton_36->setFlat(true);

        gridLayout->addWidget(pushButton_36, 4, 3, 1, 1);

        pushButton_35 = new QPushButton(centralWidget);
        pushButton_35->setObjectName(QStringLiteral("pushButton_35"));
        pushButton_35->setMinimumSize(QSize(35, 35));
        pushButton_35->setMaximumSize(QSize(35, 35));
        pushButton_35->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_35->setIcon(icon);
        pushButton_35->setIconSize(QSize(25, 25));
        pushButton_35->setFlat(true);

        gridLayout->addWidget(pushButton_35, 4, 4, 1, 1);

        pushButton_38 = new QPushButton(centralWidget);
        pushButton_38->setObjectName(QStringLiteral("pushButton_38"));
        pushButton_38->setMinimumSize(QSize(35, 35));
        pushButton_38->setMaximumSize(QSize(35, 35));
        pushButton_38->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_38->setFlat(true);

        gridLayout->addWidget(pushButton_38, 4, 5, 1, 1);

        cell = new QPushButton(centralWidget);
        cell->setObjectName(QStringLiteral("cell"));
        cell->setMinimumSize(QSize(35, 35));
        cell->setMaximumSize(QSize(35, 35));
        cell->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        cell->setFlat(true);

        gridLayout->addWidget(cell, 4, 6, 1, 1);

        pushButton_41 = new QPushButton(centralWidget);
        pushButton_41->setObjectName(QStringLiteral("pushButton_41"));
        pushButton_41->setMinimumSize(QSize(35, 35));
        pushButton_41->setMaximumSize(QSize(35, 35));
        pushButton_41->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_41->setFlat(true);

        gridLayout->addWidget(pushButton_41, 4, 7, 1, 1);

        pushButton_43 = new QPushButton(centralWidget);
        pushButton_43->setObjectName(QStringLiteral("pushButton_43"));
        pushButton_43->setMinimumSize(QSize(35, 35));
        pushButton_43->setMaximumSize(QSize(35, 35));
        pushButton_43->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 1px;"));
        pushButton_43->setFlat(true);

        gridLayout->addWidget(pushButton_43, 5, 0, 1, 1);

        pushButton_45 = new QPushButton(centralWidget);
        pushButton_45->setObjectName(QStringLiteral("pushButton_45"));
        pushButton_45->setMinimumSize(QSize(35, 35));
        pushButton_45->setMaximumSize(QSize(35, 35));
        pushButton_45->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_45->setFlat(true);

        gridLayout->addWidget(pushButton_45, 5, 1, 1, 1);

        pushButton_39 = new QPushButton(centralWidget);
        pushButton_39->setObjectName(QStringLiteral("pushButton_39"));
        pushButton_39->setMinimumSize(QSize(35, 35));
        pushButton_39->setMaximumSize(QSize(35, 35));
        pushButton_39->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_39->setFlat(true);

        gridLayout->addWidget(pushButton_39, 5, 2, 1, 1);

        pushButton_33 = new QPushButton(centralWidget);
        pushButton_33->setObjectName(QStringLiteral("pushButton_33"));
        pushButton_33->setMinimumSize(QSize(35, 35));
        pushButton_33->setMaximumSize(QSize(35, 35));
        pushButton_33->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_33->setFlat(true);

        gridLayout->addWidget(pushButton_33, 5, 3, 1, 1);

        pushButton_47 = new QPushButton(centralWidget);
        pushButton_47->setObjectName(QStringLiteral("pushButton_47"));
        pushButton_47->setMinimumSize(QSize(35, 35));
        pushButton_47->setMaximumSize(QSize(35, 35));
        pushButton_47->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_47->setFlat(true);

        gridLayout->addWidget(pushButton_47, 5, 4, 1, 1);

        pushButton_34 = new QPushButton(centralWidget);
        pushButton_34->setObjectName(QStringLiteral("pushButton_34"));
        pushButton_34->setMinimumSize(QSize(35, 35));
        pushButton_34->setMaximumSize(QSize(35, 35));
        pushButton_34->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_34->setFlat(true);

        gridLayout->addWidget(pushButton_34, 5, 5, 1, 1);

        pushButton_40 = new QPushButton(centralWidget);
        pushButton_40->setObjectName(QStringLiteral("pushButton_40"));
        pushButton_40->setMinimumSize(QSize(35, 35));
        pushButton_40->setMaximumSize(QSize(35, 35));
        pushButton_40->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_40->setFlat(true);

        gridLayout->addWidget(pushButton_40, 5, 6, 1, 1);

        pushButton_46 = new QPushButton(centralWidget);
        pushButton_46->setObjectName(QStringLiteral("pushButton_46"));
        pushButton_46->setMinimumSize(QSize(35, 35));
        pushButton_46->setMaximumSize(QSize(35, 35));
        pushButton_46->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_46->setFlat(true);

        gridLayout->addWidget(pushButton_46, 5, 7, 1, 1);

        pushButton_71 = new QPushButton(centralWidget);
        pushButton_71->setObjectName(QStringLiteral("pushButton_71"));
        pushButton_71->setMinimumSize(QSize(35, 35));
        pushButton_71->setMaximumSize(QSize(35, 35));
        pushButton_71->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 1px;"));
        pushButton_71->setFlat(true);

        gridLayout->addWidget(pushButton_71, 6, 0, 1, 1);

        pushButton_61 = new QPushButton(centralWidget);
        pushButton_61->setObjectName(QStringLiteral("pushButton_61"));
        pushButton_61->setMinimumSize(QSize(35, 35));
        pushButton_61->setMaximumSize(QSize(35, 35));
        pushButton_61->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_61->setFlat(true);

        gridLayout->addWidget(pushButton_61, 6, 1, 1, 1);

        pushButton_56 = new QPushButton(centralWidget);
        pushButton_56->setObjectName(QStringLiteral("pushButton_56"));
        pushButton_56->setMinimumSize(QSize(35, 35));
        pushButton_56->setMaximumSize(QSize(35, 35));
        pushButton_56->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_56->setFlat(true);

        gridLayout->addWidget(pushButton_56, 6, 2, 1, 1);

        pushButton_55 = new QPushButton(centralWidget);
        pushButton_55->setObjectName(QStringLiteral("pushButton_55"));
        pushButton_55->setMinimumSize(QSize(35, 35));
        pushButton_55->setMaximumSize(QSize(35, 35));
        pushButton_55->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_55->setFlat(true);

        gridLayout->addWidget(pushButton_55, 6, 3, 1, 1);

        pushButton_54 = new QPushButton(centralWidget);
        pushButton_54->setObjectName(QStringLiteral("pushButton_54"));
        pushButton_54->setMinimumSize(QSize(35, 35));
        pushButton_54->setMaximumSize(QSize(35, 35));
        pushButton_54->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_54->setFlat(true);

        gridLayout->addWidget(pushButton_54, 6, 4, 1, 1);

        pushButton_57 = new QPushButton(centralWidget);
        pushButton_57->setObjectName(QStringLiteral("pushButton_57"));
        pushButton_57->setMinimumSize(QSize(35, 35));
        pushButton_57->setMaximumSize(QSize(35, 35));
        pushButton_57->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_57->setFlat(true);

        gridLayout->addWidget(pushButton_57, 6, 5, 1, 1);

        pushButton_72 = new QPushButton(centralWidget);
        pushButton_72->setObjectName(QStringLiteral("pushButton_72"));
        pushButton_72->setMinimumSize(QSize(35, 35));
        pushButton_72->setMaximumSize(QSize(35, 35));
        pushButton_72->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_72->setFlat(true);

        gridLayout->addWidget(pushButton_72, 6, 6, 1, 1);

        pushButton_60 = new QPushButton(centralWidget);
        pushButton_60->setObjectName(QStringLiteral("pushButton_60"));
        pushButton_60->setMinimumSize(QSize(35, 35));
        pushButton_60->setMaximumSize(QSize(35, 35));
        pushButton_60->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 0px;\n"
"border-left-width: 0px;"));
        pushButton_60->setFlat(true);

        gridLayout->addWidget(pushButton_60, 6, 7, 1, 1);

        pushButton_44 = new QPushButton(centralWidget);
        pushButton_44->setObjectName(QStringLiteral("pushButton_44"));
        pushButton_44->setMinimumSize(QSize(35, 35));
        pushButton_44->setMaximumSize(QSize(35, 35));
        pushButton_44->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 1px;"));
        pushButton_44->setFlat(true);

        gridLayout->addWidget(pushButton_44, 7, 0, 1, 1);

        pushButton_52 = new QPushButton(centralWidget);
        pushButton_52->setObjectName(QStringLiteral("pushButton_52"));
        pushButton_52->setMinimumSize(QSize(35, 35));
        pushButton_52->setMaximumSize(QSize(35, 35));
        pushButton_52->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 0px;"));
        pushButton_52->setFlat(true);

        gridLayout->addWidget(pushButton_52, 7, 1, 1, 1);

        pushButton_53 = new QPushButton(centralWidget);
        pushButton_53->setObjectName(QStringLiteral("pushButton_53"));
        pushButton_53->setMinimumSize(QSize(35, 35));
        pushButton_53->setMaximumSize(QSize(35, 35));
        pushButton_53->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 0px;"));
        pushButton_53->setFlat(true);

        gridLayout->addWidget(pushButton_53, 7, 2, 1, 1);

        pushButton_65 = new QPushButton(centralWidget);
        pushButton_65->setObjectName(QStringLiteral("pushButton_65"));
        pushButton_65->setMinimumSize(QSize(35, 35));
        pushButton_65->setMaximumSize(QSize(35, 35));
        pushButton_65->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 0px;"));
        pushButton_65->setFlat(true);

        gridLayout->addWidget(pushButton_65, 7, 3, 1, 1);

        pushButton_66 = new QPushButton(centralWidget);
        pushButton_66->setObjectName(QStringLiteral("pushButton_66"));
        pushButton_66->setMinimumSize(QSize(35, 35));
        pushButton_66->setMaximumSize(QSize(35, 35));
        pushButton_66->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 0px;"));
        pushButton_66->setFlat(true);

        gridLayout->addWidget(pushButton_66, 7, 4, 1, 1);

        pushButton_67 = new QPushButton(centralWidget);
        pushButton_67->setObjectName(QStringLiteral("pushButton_67"));
        pushButton_67->setMinimumSize(QSize(35, 35));
        pushButton_67->setMaximumSize(QSize(35, 35));
        pushButton_67->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 0px;"));
        pushButton_67->setFlat(true);

        gridLayout->addWidget(pushButton_67, 7, 5, 1, 1);

        pushButton_68 = new QPushButton(centralWidget);
        pushButton_68->setObjectName(QStringLiteral("pushButton_68"));
        pushButton_68->setMinimumSize(QSize(35, 35));
        pushButton_68->setMaximumSize(QSize(35, 35));
        pushButton_68->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 0px;"));
        pushButton_68->setFlat(true);

        gridLayout->addWidget(pushButton_68, 7, 6, 1, 1);

        pushButton_69 = new QPushButton(centralWidget);
        pushButton_69->setObjectName(QStringLiteral("pushButton_69"));
        pushButton_69->setMinimumSize(QSize(35, 35));
        pushButton_69->setMaximumSize(QSize(35, 35));
        pushButton_69->setStyleSheet(QLatin1String("background-color: white;\n"
"border-color: black;\n"
"border-style: solid;\n"
"border-top-width: 1px;\n"
"border-right-width: 1px;\n"
"border-bottom-width: 1px;\n"
"border-left-width: 0px;"));
        pushButton_69->setFlat(true);

        gridLayout->addWidget(pushButton_69, 7, 7, 1, 1);

        Reversi->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Reversi);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 300, 21));
        menuJogo = new QMenu(menuBar);
        menuJogo->setObjectName(QStringLiteral("menuJogo"));
        menuAjuda = new QMenu(menuBar);
        menuAjuda->setObjectName(QStringLiteral("menuAjuda"));
        Reversi->setMenuBar(menuBar);
        statusBar = new QStatusBar(Reversi);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Reversi->setStatusBar(statusBar);

        menuBar->addAction(menuJogo->menuAction());
        menuBar->addAction(menuAjuda->menuAction());

        retranslateUi(Reversi);

        QMetaObject::connectSlotsByName(Reversi);
    } // setupUi

    void retranslateUi(QMainWindow *Reversi)
    {
        Reversi->setWindowTitle(QApplication::translate("Reversi", "Reversi", nullptr));
        menuJogo->setTitle(QApplication::translate("Reversi", "Jogo", nullptr));
        menuAjuda->setTitle(QApplication::translate("Reversi", "Ajuda", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Reversi: public Ui_Reversi {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REVERSI_H
