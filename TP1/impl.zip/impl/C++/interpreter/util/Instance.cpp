#include "Instance.h"

Instance::Instance() {
}

Instance::~Instance() {
}
