#include "Arguments.h"

Arguments::Arguments() {
}

Arguments::~Arguments() {
}
