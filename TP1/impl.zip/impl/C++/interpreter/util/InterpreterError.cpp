#include "InterpreterError.h"

#include <cstdio>
#include <cstdlib>

InterpreterError::InterpreterError() {
}

void InterpreterError::abort(int line) {
    printf("%02d: Operação inválida\n", line);
    exit(1);
}