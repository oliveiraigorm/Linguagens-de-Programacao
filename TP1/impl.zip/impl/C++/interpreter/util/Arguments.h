#ifndef ARGUMENTS_H
#define ARGUMENTS_H

#include "Memory.h"

class Arguments : public Memory {
    public:
        Arguments();
        virtual ~ Arguments();

};

#endif