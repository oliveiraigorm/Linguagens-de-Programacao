#ifndef INTERPRETER_ERROR
#define INTERPRETER_ERROR

class InterpreterError {
    public:
        static void abort(int line);

    private:
        InterpreterError();
};

#endif