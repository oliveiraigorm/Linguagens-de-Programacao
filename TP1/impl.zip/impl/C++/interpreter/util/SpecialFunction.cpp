#include "SpecialFunction.h"

#include <string>
#include <cstdlib>
#include <iostream>

#include "Arguments.h"
#include "../value/StringValue.h"
#include "../value/IntegerValue.h"

SpecialFunction::SpecialFunction(FunctionType type) : m_type(type) {
}

SpecialFunction::~SpecialFunction() {
}

Type* SpecialFunction::call(Instance* self, Arguments* args) {
    Type* value;

    switch (m_type) {
        case PrintFunction:
            value = this->print(args);
            break;
        case PrintlnFunction:
            value = this->println(args);
            break;
        case ReadFunction:
            value = this->read(args);
            break;
        default:
            throw std::string("FIXME: Implement me!");
    }

    return value;
}

Type* SpecialFunction::print(Arguments* args) {
    if (args->contains("args1")) {
        Type* v = args->value("args1");
        if (v->type() == Type::IntegerType) {
            IntegerValue* iv = (IntegerValue*) v;
            printf("%d", iv->value());
        } else if (v->type() == Type::StringType) {
            StringValue* sv = (StringValue*) v;
            printf("%s", sv->value().c_str());
        } else {
            throw std::string("FIXME: Implement me!");
        }
    }

    return IntegerValue::Zero;
}

Type* SpecialFunction::println(Arguments* args) {
    Type* v = this->print(args);
    printf("\n");
    return v;
}

Type* SpecialFunction::read(Arguments* args) {
    // Print the argument.
    Type* v = this->print(args);

    std::string input;
    std::cin >> input;

    char* valid;
    int n = (int) strtol(input.c_str(), &valid, 10);
    if (valid == 0) {
        IntegerValue* iv = new IntegerValue(n);
        return iv;
    } else {
        StringValue* sv = new StringValue(input);
        return sv;
    }

}
