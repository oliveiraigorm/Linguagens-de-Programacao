#include "Function.h"
#include "../value/IntegerValue.h"

Function::Function() {
}

Function::~Function() {
}