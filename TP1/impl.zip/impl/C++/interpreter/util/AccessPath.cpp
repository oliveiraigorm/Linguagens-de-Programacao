#include "AccessPath.h"

#include <sstream>

#include "Global.h"
#include "Memory.h"
#include "Instance.h"
#include "Arguments.h"
#include "InterpreterError.h"
#include "../value/Type.h"
#include "../value/IntegerValue.h"
#include "../value/InstanceValue.h"

AccessPath::AccessPath(std::string name, int line) : m_line(line) {
    m_names.push_back(name);
}

AccessPath::~AccessPath() {
}

void AccessPath::addName(std::string name) {
    m_names.push_back(name);
}

std::list<std::string> AccessPath::names() const {
    return m_names;
}

Type* AccessPath::value(Instance* self, Arguments* args) {
    std::string name = this->lastName();
    Memory* ref = this->reference(self, args);

    if (ref->contains(name))
        return ref->value(name);
    else {
        ref->setValue(name, IntegerValue::Zero);
        return IntegerValue::Zero;
    }
}

void AccessPath::setValue(Instance* self, Arguments* args, Type* value) {
    std::string name = this->lastName();
    Memory* ref = this->reference(self, args);
    ref->setValue(name, value);
}

Memory* AccessPath::reference(Instance* self, Arguments* args) {
    std::string name;
    Memory* ref;
    std::list<std::string>::iterator it, last;

    it = m_names.begin();
    name = *it;
    if (name == "self") {
        if (self == 0)
            InterpreterError::abort(m_line);

        ref = self;
        it++;
    } else if (name == "args") {
        if (self == 0)
            InterpreterError::abort(m_line);

        ref = args;
        it++;
    } else {
        ref = Global::getGlobalTable();
    }

    last = m_names.end();
    last--;

    for (; it != last; it++) {
        Memory* new_ref;

        name = *it;
        if (ref->contains(name) && ref->value(name)->type() == Type::InstanceType) {
            // the access points already to an instance value.
            InstanceValue* iv = (InstanceValue*) ref->value(name);
            new_ref = iv->value();
        } else {
            // if there are more names, than it must be an instance (object) reference.
            Instance* new_obj = new Instance();
            ref->setValue(name, new InstanceValue(new_obj));
            new_ref = new_obj;
        }

        ref = new_ref;
    }

    return ref;
}

std::string AccessPath::lastName() const {
    return m_names.back();
}

std::string AccessPath::str() const {
    std::stringstream ss;
    
    std::list<std::string>::const_iterator it = m_names.begin();
    ss << *it;
    it++;

    for (; it != m_names.end(); it++) {
        ss << "." << *it;
    }

    return ss.str();
}