package interpreter.util;

public class Instance extends Memory {

    public Instance() {
    }

}
