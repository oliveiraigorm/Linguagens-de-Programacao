package interpreter.util;

public class Arguments extends Memory {

    public Arguments() {
    }

}
