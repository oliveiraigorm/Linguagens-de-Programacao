package lexical;

public enum TokenType {
    // special tokens
    INVALID_TOKEN,
    UNEXPECTED_EOF,
    END_OF_FILE,

    // symbols
    OPEN_CUR,
    OPEN_PAR,
    CLOSE_CUR,
    CLOSE_PAR,
    COMMA,
    DOT,
    DOT_COMMA,
    ASSIGN,
    
    
    // keywords
    IF,
    ELSE,
    WHILE,
    SYSTEM,
    SELF,
    ARGS,
    
    

    // operators
    NOT,
    AND,
    OR,
    EQUAL,
    DIFF,
    GREATER,
    LOWER,
    GREATER_EQUAL,
    LOWER_EQUAL,
    
    ADD,
    SUB,
    MULT,
    DIV,
    MOD,
    
    
    // others
    NAME,
    NUMBER,
    STRING,
    FUNCTION,
    RETURN,
};



