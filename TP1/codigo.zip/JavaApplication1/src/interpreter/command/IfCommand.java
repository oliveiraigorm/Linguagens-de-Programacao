/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreter.command;

import interpreter.expr.BoolExpr;
import interpreter.util.Arguments;
import interpreter.util.Instance;

/**
 *
 * @author olive
 */
public class IfCommand extends Command{
    BoolExpr cond;
    Command then;
    Command Else;

    public IfCommand(BoolExpr cond, Command then, int line) {
        super(line);
        this.cond = cond;
        this.then = then;
    }

    public IfCommand(BoolExpr cond, Command then, Command Else, int line) {
        super(line);
        this.cond = cond;
        this.then = then;
        this.Else = Else;
    }
    
    public void execute(Instance self, Arguments args){
        if(cond.expr(self, args)==true){
           then.execute(self, args);
       }
       else if(Else instanceof Command && Else != null){
           Else.execute(self, args);
       }else{
           //abort
       }
    }
    
}
