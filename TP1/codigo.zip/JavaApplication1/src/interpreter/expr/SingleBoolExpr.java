/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreter.expr;

import interpreter.util.Arguments;
import interpreter.util.Instance;

/**
 *
 * @author Aluno
 */
public class SingleBoolExpr extends BoolExpr{
    Expr left;
    ReloOp op;
    Expr right;
    
    public SingleBoolExpr(int line) {
        super(line);
    }
    public boolean expr(Instance self, Arguments args){
        return ;
    }
}
