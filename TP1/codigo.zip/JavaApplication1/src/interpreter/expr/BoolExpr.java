/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreter.expr;

import interpreter.util.Arguments;
import interpreter.util.Instance;
import interpreter.value.Value;

/**
 *
 * @author olive
 */
public class BoolExpr extends Expr{
    
    private int line;
    
    protected BoolExpr(int line) {
        super(line);
    }
    public int getline(){
        return 0;
    }

    @Override
    public Value<?> rhs(Instance self, Arguments args) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean expr(Instance self, Arguments args){
        
    }
   
   
}
